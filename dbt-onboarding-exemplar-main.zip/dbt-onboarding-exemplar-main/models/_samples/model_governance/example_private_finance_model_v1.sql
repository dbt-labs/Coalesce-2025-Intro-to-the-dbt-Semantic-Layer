select *
from {{ ref('fct_orders') }}
