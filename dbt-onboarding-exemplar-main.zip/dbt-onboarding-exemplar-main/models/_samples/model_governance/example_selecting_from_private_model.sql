
select * 

-- defaults to the latest version because didnt specify the version in the ref
from {{ ref('example_private_finance_model') }}


