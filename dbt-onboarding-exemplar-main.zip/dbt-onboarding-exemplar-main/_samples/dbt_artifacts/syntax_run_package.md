### Syntax to run all models from the package

Run the following command in the dbt command bar to test your project using the package 

```
dbt run --select package:dbt_artifacts
```