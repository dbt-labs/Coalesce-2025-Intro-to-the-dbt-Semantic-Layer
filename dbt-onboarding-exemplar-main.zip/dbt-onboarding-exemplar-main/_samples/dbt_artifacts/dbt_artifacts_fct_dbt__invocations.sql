select *
from {{ ref('fct_dbt__invocations') }}