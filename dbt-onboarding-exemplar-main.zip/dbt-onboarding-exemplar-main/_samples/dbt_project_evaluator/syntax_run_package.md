### Syntax to build and test all models from the package

Run the following command in the dbt command bar to test your project using the package 

```
dbt build --select package:dbt_project_evaluator
```